# REST-and-Microservices

REST and Microservices examples

A simple example of microservices that is described in this blog post.

In this we will see how to create awesome Microservices and RESTful web services using Eureka and Feign Client with Spring and Spring Boot.

We are using MYSQL database.

Tools you will need

-Maven 3.0+ is your build tool.

-Your favorite IDE. We use Eclipse.

-JDK 1.8+

-MYSQL

-Postman

So,first we will be seeing standalone REST API for Bank application and then we break this application into Microserevices with Eureka and Feign Client.

