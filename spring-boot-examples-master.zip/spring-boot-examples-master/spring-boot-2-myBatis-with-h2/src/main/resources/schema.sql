create table student
(
   id integer not null,
   name varchar(255) not null,
   passport varchar(255) not null,
   primary key(id)
);