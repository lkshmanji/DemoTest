#!/bin/bash
echo "********************************************************"
echo "      Starting Sip-Server-Config-Service        "
echo "********************************************************"
java -jar @project.build.finalName@.jar
