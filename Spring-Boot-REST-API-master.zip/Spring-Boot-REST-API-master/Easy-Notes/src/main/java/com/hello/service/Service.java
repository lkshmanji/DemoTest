package com.hello.service;

import org.springframework.context.annotation.Profile;

@org.springframework.stereotype.Service
@Profile("test1")
public interface Service {

}
