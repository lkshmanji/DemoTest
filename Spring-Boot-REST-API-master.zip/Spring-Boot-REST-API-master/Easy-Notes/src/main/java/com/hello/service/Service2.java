package com.hello.service;

import org.springframework.context.annotation.Profile;

@org.springframework.stereotype.Service
@Profile("test2")
public interface Service2 {

	
	
}
