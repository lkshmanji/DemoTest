//package com.hello;
//
//import static org.junit.Assert.*;
//
//import java.util.List;
//
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//
//import com.hello.model.Note;
//import com.hello.service.Service;
//
//@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest
//public class ServiceImplTest {
//
//	
//	@Autowired
//	Service service;;
//	
//	/*@Test
//	public void verifyFindByTitle() {
//
//		Note note=new Note();
//		note.setTitle("My Fourth Note");
//		List<Note> list=service.findByTitle(note.getTitle());
//		assertNotNull(list);
//
//	}*/
//}
