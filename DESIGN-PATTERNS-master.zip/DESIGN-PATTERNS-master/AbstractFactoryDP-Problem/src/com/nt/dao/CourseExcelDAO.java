package com.nt.dao;

public class CourseExcelDAO implements DAO {

	@Override
	public void insert() {
		System.out.println("CourseExcelDAO::Inserting Course Details to Excel.....");
	}

}
