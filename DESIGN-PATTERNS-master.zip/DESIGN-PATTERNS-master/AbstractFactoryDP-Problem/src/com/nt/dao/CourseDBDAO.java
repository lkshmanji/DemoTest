package com.nt.dao;

public class CourseDBDAO implements DAO {

	@Override
	public void insert() {
		System.out.println("CourseDBDAO::Inserting Course Details to DB .....");
	}

}
