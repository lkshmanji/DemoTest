package com.nt.comp;

public interface Shape {
	public  void draw(int arg0,String fillColor,String lineStyle);

}
