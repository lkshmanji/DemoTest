package com.nt.comps;

public class HireDotNetFresher {
	public  boolean conductAptitudeTest(){
		System.out.println("Aptitude Test");
		return true;
	}
	
	public  boolean conductGDTest(){
		System.out.println("GD Test");
		return true;
	}
	
	public  boolean conductTechnicalTest(){
		System.out.println("DotNet Technical Test");
		return true;
	}
	
	public  boolean conductSystemTest(){
		System.out.println("DotNet System Test");
		return true;
	}
	
	public  boolean conductHRInterview(){
		System.out.println("HR Interview");
		return true;
	}
	

}
