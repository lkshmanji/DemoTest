package com.nt.comps;

public class HireJavaFresher {
	public  boolean conductAptitudeTest(){
		System.out.println("Aptitude Test");
		return true;
	}
	
	public  boolean conductGDTest(){
		System.out.println("GD Test");
		return true;
	}
	
	public  boolean conductTechnicalTest(){
		System.out.println("Java Technical Test");
		return true;
	}
	
	public  boolean conductSystemTest(){
		System.out.println("Java System Test");
		return false;
	}
	
	public  boolean conductHRInterview(){
		System.out.println("HR Interview");
		return true;
	}
	

}
