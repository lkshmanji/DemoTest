package com.nt.service;

public interface FBDayWelcomeService {
	  public  float  getTemparature(String cityName,String countryName)throws IllegalArgumentException; 

}
