package com.nt.external;

public interface WeatherReportComp {
	
	public  float  getTemperature(int cityCode,int countryCode)throws IllegalArgumentException;

}
