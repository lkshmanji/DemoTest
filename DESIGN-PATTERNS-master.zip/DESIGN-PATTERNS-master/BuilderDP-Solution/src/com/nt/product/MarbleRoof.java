package com.nt.product;

public class MarbleRoof implements Roof {

	@Override
	public String toString() {
		return "Marble-white cement Roof ";
	}
	

}
