package com.nt.product;

public class ConcreteRoof implements Roof {

	@Override
	public String toString() {
		return "Concrete-Iron Roof ";
	}
	

}
