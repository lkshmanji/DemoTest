package com.nt.product;

public class IceRoof implements Roof {

	@Override
	public String toString() {
		return "ICe-chemical Roof ";
	}
	

}
