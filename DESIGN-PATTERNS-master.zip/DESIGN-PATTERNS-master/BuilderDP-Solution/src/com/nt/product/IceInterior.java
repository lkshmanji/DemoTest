package com.nt.product;

public class IceInterior  implements Interiror {

	@Override
	public String toString() {
		return "Ice Craving- Interior ";
	}
	
	

}
