package com.nt.product;

public class WoodenStructure implements Structure {

	@Override
	public String toString() {
		return "Wooden Beams Structure ";
	}
	
	

}
