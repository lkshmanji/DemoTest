package com.nt.product;

public class WoodenInterior  implements Interiror {

	@Override
	public String toString() {
		return "Wooden-Glass Interior ";
	}
	
	

}
