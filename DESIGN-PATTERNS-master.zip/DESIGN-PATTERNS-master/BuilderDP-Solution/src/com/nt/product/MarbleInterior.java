package com.nt.product;

public class MarbleInterior  implements Interiror {

	@Override
	public String toString() {
		return "Marble-Glass Interior ";
	}
	
	

}
