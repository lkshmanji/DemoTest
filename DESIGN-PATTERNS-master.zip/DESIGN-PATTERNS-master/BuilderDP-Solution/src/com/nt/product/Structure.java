package com.nt.product;

public interface Structure {

}
