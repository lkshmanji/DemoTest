package com.nt.product;

public class IceStructure implements Structure {

	@Override
	public String toString() {
		return "Ice-Chemical Beams Structure ";
	}
	
	

}
