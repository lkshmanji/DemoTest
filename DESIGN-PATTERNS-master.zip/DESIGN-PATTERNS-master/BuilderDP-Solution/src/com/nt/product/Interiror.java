package com.nt.product;

public interface Interiror {
	

}
