package com.nt.comp;

public interface Shape {
	public  void draw();

}
