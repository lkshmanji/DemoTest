package com.nt.comps;

public interface CourseMeterial {
	
	public  String   courseContent();

}
