package com.nt.comps;

public final class JavaCourseMaterial implements CourseMeterial{

	@Override
	public String courseContent() {
		return "java courses Content--> core java,adv.java,spring,DP,hibernate,...";
	}

}
