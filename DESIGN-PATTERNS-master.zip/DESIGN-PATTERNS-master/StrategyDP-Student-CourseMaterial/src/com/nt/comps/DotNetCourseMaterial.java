package com.nt.comps;

public final class DotNetCourseMaterial implements CourseMeterial{

	@Override
	public String courseContent() {
		return ".Net courses Content--> c#,asp.net,asp.net mvc,SQLserver,...";
	}

}
