package com.nt.comps;

public final class TestingCourseMaterial implements CourseMeterial{

	@Override
	public String courseContent() {
		return "Testing tools course content--> selenium,apium,junit ,...";
	}

}
