package com.nt.bo;

public class HREmpBO extends BaseEmpBO {
	private String empDesg;

	public String getEmpDesg() {
		return empDesg;
	}

	public void setEmpDesg(String empDesg) {
		this.empDesg = empDesg;
	}

}
