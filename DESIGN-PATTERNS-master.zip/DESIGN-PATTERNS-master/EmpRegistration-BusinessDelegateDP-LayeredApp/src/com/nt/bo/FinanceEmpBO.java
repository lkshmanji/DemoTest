package com.nt.bo;

public class FinanceEmpBO extends BaseEmpBO {
	private float empSalary;

	public float getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(float empSalary) {
		this.empSalary = empSalary;
	}


}
