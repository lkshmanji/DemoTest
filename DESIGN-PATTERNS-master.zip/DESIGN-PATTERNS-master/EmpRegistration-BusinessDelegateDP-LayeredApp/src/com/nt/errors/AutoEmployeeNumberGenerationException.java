package com.nt.errors;

public class AutoEmployeeNumberGenerationException extends Exception {

	public AutoEmployeeNumberGenerationException(String msg) {
		super(msg);
	}
}
