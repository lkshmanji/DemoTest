package com.nt.errors;

public class CrickterProfileFinderException extends Exception {
	public CrickterProfileFinderException(String msg) {
	   super(msg);
	}

}
