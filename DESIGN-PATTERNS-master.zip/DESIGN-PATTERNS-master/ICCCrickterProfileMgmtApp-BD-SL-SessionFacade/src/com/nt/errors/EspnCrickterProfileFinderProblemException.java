package com.nt.errors;

public class EspnCrickterProfileFinderProblemException extends Exception {

	public EspnCrickterProfileFinderProblemException(String msg) {
		super(msg);
	}
	
}
