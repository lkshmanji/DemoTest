package com.nt.errors;

public class CrickterIdFinderException extends Exception {
	public CrickterIdFinderException(String msg) {
	   super(msg);
	}

}
