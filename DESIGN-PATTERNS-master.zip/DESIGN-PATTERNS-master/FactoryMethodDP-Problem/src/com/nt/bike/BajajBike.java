package com.nt.bike;

public abstract class BajajBike {
	protected String engineCC;
	protected  String gearCount;
	public  abstract void  drive();

}
