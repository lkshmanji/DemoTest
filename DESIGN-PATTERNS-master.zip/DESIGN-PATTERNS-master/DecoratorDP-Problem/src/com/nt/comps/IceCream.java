package com.nt.comps;

public interface IceCream {
	public  void prepare();

}
