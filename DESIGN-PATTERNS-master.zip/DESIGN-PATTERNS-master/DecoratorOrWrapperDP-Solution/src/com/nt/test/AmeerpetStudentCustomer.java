package com.nt.test;

import com.nt.component.AndriodMobile;
import com.nt.component.Mobile;

public class AmeerpetStudentCustomer {
	public static void main(String[] args) {
		Mobile mobile=null;
		mobile=new AndriodMobile();
		mobile.purchase();
		System.out.println("................................");
	}

}
