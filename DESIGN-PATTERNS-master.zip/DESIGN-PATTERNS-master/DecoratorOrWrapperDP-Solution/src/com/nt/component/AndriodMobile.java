//AndrioidMobile.java (ConcreteComponent class)
package com.nt.component;

public class AndriodMobile implements Mobile {

	@Override
	public void purchase() {
	   System.out.println("Andriod Basic Mobile");

	}

}
