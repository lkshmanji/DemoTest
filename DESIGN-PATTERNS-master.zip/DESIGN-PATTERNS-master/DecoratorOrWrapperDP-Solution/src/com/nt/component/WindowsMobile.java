//WindowsMobile.java (Concrete Component class)
package com.nt.component;

public class WindowsMobile implements Mobile {

	@Override
	public void purchase() {
	   System.out.println("Windows Basic Mobile");

	}

}
