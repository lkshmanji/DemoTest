//Mobile.java (Component Interface)
package com.nt.component;

public interface Mobile {
    public void  purchase();
}
