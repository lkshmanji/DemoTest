//IOSMobile.java (ConcreteComponent class)

package com.nt.component;

public class IOSMobile implements Mobile {

	@Override
	public void purchase() {
		System.out.println("IOS Basic Mobile");
		
	}

}
