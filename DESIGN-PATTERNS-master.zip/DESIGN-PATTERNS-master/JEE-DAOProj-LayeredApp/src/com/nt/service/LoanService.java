package com.nt.service;

import com.nt.dto.LoanDetailsDTO;

public interface LoanService {
    public  String  registerCustomer(LoanDetailsDTO dto)throws Exception;
}
