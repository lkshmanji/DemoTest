package com.nt.item;

public abstract class Car {
	 private  String modelName;
	 private  String engineType;
	 private String engineCC;
	 
	 public abstract void  assemble();
	 public abstract void  roadTest();
	 public  abstract void  deliver();
	

}
