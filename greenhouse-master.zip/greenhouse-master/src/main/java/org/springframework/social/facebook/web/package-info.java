/**
 * Spring Social Facebook Web Extensions.
 */
package org.springframework.social.facebook.web;

