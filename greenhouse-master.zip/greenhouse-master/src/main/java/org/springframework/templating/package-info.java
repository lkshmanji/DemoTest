/**
 * Spring Framework extensions for string templating, particularly useful in constructing emails.
 */
package org.springframework.templating;

