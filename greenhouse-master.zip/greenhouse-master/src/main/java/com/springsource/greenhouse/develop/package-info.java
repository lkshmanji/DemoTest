/**
 * Lets developers connect their apps to a server-side API securely with OAuth.
 */
package com.springsource.greenhouse.develop;

