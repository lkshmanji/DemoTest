/**
 * OAuth session management that integrates with the Spring Security-based OAuth Provider.
 */
package com.springsource.greenhouse.develop.oauth;

