/**
 * Domain package for managing public member profiles.
 */
package com.springsource.greenhouse.members;

