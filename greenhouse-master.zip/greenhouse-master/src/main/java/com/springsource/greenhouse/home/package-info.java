/**
 * UI control logic that applies to the application home page or across all pages.
 */
package com.springsource.greenhouse.home;

