/**
 * Functionality for signing-in and authenticating existing members.
 */
package com.springsource.greenhouse.signin;

