package com.mkyong.core.services;

public interface HelloService {

    String get();

}
