# Spring Boot + JUnit 5 + Mockito

Article link : https://www.mkyong.com/spring-boot/spring-boot-junit-5-mockito/

## 1. How to start
```
$ mvn test
```
