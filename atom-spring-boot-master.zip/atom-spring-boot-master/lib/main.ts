import {SpringBootLanguageClient} from './spring-boot-language-client';

module.exports = new SpringBootLanguageClient();