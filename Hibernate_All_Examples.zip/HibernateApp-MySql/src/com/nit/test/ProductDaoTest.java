package com.nit.test;

import com.nit.dao.ProductDao;
import com.nit.entities.Product;

public class ProductDaoTest {
	public static void main(String[] args) {

		// Setting data to Entity object
		Product entity = new Product();
		entity.setPid(1001);
		entity.setName("Keyboard");
		entity.setPrice(14500.00);

		// Calling Dao method to persist entity data
		ProductDao dao = new ProductDao();
		boolean isInserted = dao.insert(entity);
		System.out.println("Record inserted : " + isInserted);
	}
}
