package com.nit.oto.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.nit.oto.entities.Person;

public class PersonDao {

	public void insert(Person p) {
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session hs = sf.openSession();
		Transaction tx = hs.beginTransaction();
		hs.save(p);
		tx.commit();
		hs.close();
	}

	public void retrieve(Integer personId) {
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session hs = sf.openSession();
		Transaction tx = hs.beginTransaction();
		Person p = (Person) hs.get(Person.class, personId);
		System.out.println(p);
		tx.commit();
		hs.close();
	}

}
