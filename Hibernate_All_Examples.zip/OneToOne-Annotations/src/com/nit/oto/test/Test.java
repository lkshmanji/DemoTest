package com.nit.oto.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.nit.oto.dao.PersonDao;
import com.nit.oto.entities.Address;

public class Test {

	public static void main(String[] args) throws Exception {

		PersonDao dao = new PersonDao();

		/*
		 * SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
		 * 
		 * Person person = new Person(); person.setPersonName("Raju");
		 * person.setDob(sdf.parse("10-May-1991"));
		 * 
		 * Passport passport = new Passport();
		 * passport.setPassportNum("KY23545"); passport.setIssuedDt(new Date());
		 * passport.setExpirtyDt(sdf.parse("17-Nov-2027"));
		 * 
		 * person.setPassport(passport); passport.setPerson(person);
		 * 
		 * dao.insert(person);
		 */

		// dao.retrieve(1);

		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session hs = sf.openSession();
		Transaction tx = hs.beginTransaction();
		Address addr = new Address();
		addr.setAid(5);
		addr.setCity("Hyderabd");
		addr.setAddrLine1("S.R Nagar");
		hs.delete(addr);
		tx.commit();
		hs.close();

	}

}
