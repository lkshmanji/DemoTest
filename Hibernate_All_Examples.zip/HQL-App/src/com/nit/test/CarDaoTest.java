package com.nit.test;

import java.util.Date;


import java.util.List;

import com.nit.dao.CarDao;
import com.nit.entities.Car;

public class CarDaoTest {

	public static void main(String[] args) {
		CarDao dao = new CarDao();

		/*Car c = new Car();
		c.setCarColor("White");
		c.setCarName("Safari");
		c.setMfgDt(new Date());
		boolean flag = dao.insert(c);
		System.out.println("Status : " + flag);*/
		
		/*List<Car> list =  dao.findAll();
		if(!list.isEmpty()){
			for(Car c  : list){
				System.out.println(c);
			}
		}*/
		/*Car c = dao.findById(7);
		System.out.println(c);*/
		
		//List<Car> list =  dao.findByColor("Red");
		
		/*List<Car> list = dao.findByPagination();
		if(!list.isEmpty()){
			for(Car c  : list){
				System.out.println(c);
			}
		}*/
		
		/*List<Object[]> listObjArr = dao.findIdAndName();
		for (Object[] objArr : listObjArr) {
			System.out.print(objArr[0] + "\t");
			System.out.println(objArr[1]);
		}*/
		
		/*List<String> colors = dao.findUniqueColors();
		for(String color : colors){
			System.out.println(color);
		}*/
		
		/*Integer maxCarId = dao.findMaxcarId();
		System.out.println("Max Car Id : "+maxCarId);*/
		//dao.updatePriceByColor(200000.00, "Black");
		
		List<Car> list =  dao.findAllUsingNamedQuery();
		if(!list.isEmpty()){
			for(Car c  : list){
				System.out.println(c);
			}
		}
	}

}
