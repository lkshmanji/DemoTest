package com.nit.dao;

import java.io.Serializable;
import java.util.List;

import javax.persistence.NamedNativeQuery;
import javax.persistence.Query;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.nit.entities.Car;

public class CarDao {
	public boolean insert(Car entity) {
		boolean isInserted = false;
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session hs = sf.openSession();
		Transaction tx = hs.beginTransaction();
		Serializable id = hs.save(entity);
		if (id != null) {
			isInserted = true;
		}
		tx.commit();
		hs.close();
		sf.close();
		return isInserted;
	}

	public List<Car> findAll() {
		List<Car> carsList = null;
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session hs = sf.openSession();
		String hqlQuery = "From Car";
		Query query = hs.createQuery(hqlQuery);
		carsList = query.getResultList();
		hs.close();
		return carsList;
	}

	public List<Car> findAllUsingNamedQuery() {
		List<Car> carsList = null;
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session hs = sf.openSession();

		Query query = hs.getNamedQuery("find_all_nq");

		carsList = query.getResultList();
		hs.close();
		return carsList;
	}

	public Car findById(int cid) {
		List<Car> carsList = null;
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session hs = sf.openSession();
		String hqlQuery = "From Car where carId=:cid";
		Query query = hs.createQuery(hqlQuery);

		query.setParameter("cid", cid);
		carsList = query.getResultList();
		hs.close();
		if (!carsList.isEmpty()) {
			return carsList.get(0);
		}
		return null;
	}

	public List<Car> findByColor(String color) {
		List<Car> carsList = null;
		try {
			Configuration cfg = new Configuration();
			cfg.configure();
			SessionFactory sf = cfg.buildSessionFactory();
			Session hs = sf.openSession();
			String hqlQuery = "From Car where carColor=:clr";
			Query query = hs.createQuery(hqlQuery);
			query.setParameter("clr", color);
			carsList = query.getResultList();
			hs.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return carsList;
	}

	public List<Car> findByPagination() {
		List<Car> carsList = null;
		try {
			Configuration cfg = new Configuration();
			cfg.configure();
			SessionFactory sf = cfg.buildSessionFactory();
			Session hs = sf.openSession();
			String hqlQuery = "From Car";
			Query query = hs.createQuery(hqlQuery);
			// Using pagination methods
			query.setFirstResult(3);
			query.setMaxResults(3);
			carsList = query.getResultList();
			hs.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return carsList;
	}

	public List<Object[]> findIdAndName() {
		List<Object[]> carsList = null;
		try {
			Configuration cfg = new Configuration();
			cfg.configure();
			SessionFactory sf = cfg.buildSessionFactory();
			Session hs = sf.openSession();
			String hql = "select carId,carName from Car";
			Query query = hs.createQuery(hql);
			carsList = query.getResultList();
			hs.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return carsList;
	}

	public List<String> findUniqueColors() {
		List<String> cololrsList = null;
		try {
			Configuration cfg = new Configuration();
			cfg.configure();
			SessionFactory sf = cfg.buildSessionFactory();
			Session hs = sf.openSession();
			String hql = "select distinct(carColor) from Car";
			Query query = hs.createQuery(hql);
			cololrsList = query.getResultList();
			hs.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return cololrsList;
	}

	public Integer findMaxcarId() {
		List<Integer> list = null;
		try {
			Configuration cfg = new Configuration();
			cfg.configure();
			SessionFactory sf = cfg.buildSessionFactory();
			Session hs = sf.openSession();
			String hql = "select max(carId) from Car";
			Query query = hs.createQuery(hql);
			list = query.getResultList();
			hs.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (!list.isEmpty()) {
			return list.get(0);
		}
		return 0;
	}

	public void updatePriceByColor(Double price, String color) {
		List<Integer> list = null;
		try {
			Configuration cfg = new Configuration();
			cfg.configure();
			SessionFactory sf = cfg.buildSessionFactory();
			Session hs = sf.openSession();
			Transaction tx = hs.beginTransaction();
			String hql = "UPDATE Car set carPrice=:price where carColor=:color";

			Query query = hs.createQuery(hql);
			query.setParameter("price", price);
			query.setParameter("color", color);

			int rowsEffected = query.executeUpdate();
			tx.commit();
			System.out.println("Rows Effected : " + rowsEffected);
			hs.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
