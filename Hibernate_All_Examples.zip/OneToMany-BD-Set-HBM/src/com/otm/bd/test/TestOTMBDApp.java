package com.otm.bd.test;

import com.otm.bd.dao.AuthorBooksDao;

public class TestOTMBDApp {

	public static void main(String[] args) {
		AuthorBooksDao dao = new AuthorBooksDao();
		// dao.saveAuthorWithBooks();
		dao.findBookById(1);
	}
}
