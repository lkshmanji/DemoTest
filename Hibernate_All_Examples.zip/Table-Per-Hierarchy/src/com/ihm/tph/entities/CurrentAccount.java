package com.ihm.tph.entities;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("C")
public class CurrentAccount extends Account {

	@Column(name = "TX_LIMIT")
	private Double txLimit;

	public Double getTxLimit() {
		return txLimit;
	}

	public void setTxLimit(Double txLimit) {
		this.txLimit = txLimit;
	}

}
