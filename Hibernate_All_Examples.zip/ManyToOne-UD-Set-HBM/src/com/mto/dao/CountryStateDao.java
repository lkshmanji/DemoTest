package com.mto.dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.mto.entities.Country;
import com.mto.entities.State;
import com.mto.util.HibernateUtils;

public class CountryStateDao {
	public boolean saveStatesWithCountry() {
		boolean isInserted = false;
		Session hs = null;
		Transaction tx = null;
		try {
			hs = HibernateUtils.getSession();
			tx = hs.beginTransaction();

			Country c = new Country();
			c.setCountryName("India");
			c.setCountryCode("+91");

			State s1 = new State();
			s1.setStateName("AP");
			s1.setCountry(c);

			State s2 = new State();
			s2.setStateName("TG");
			s2.setCountry(c);

			State s3 = new State();
			s3.setStateName("Karnataka");
			s3.setCountry(c);

			hs.save(s1);
			hs.save(s2);
			hs.save(s3);

			tx.commit();
			hs.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return isInserted;

	}

	public void findStateById(int sid) {
		Session hs = null;
		try {
			hs = HibernateUtils.getSession();

			State s = hs.get(State.class, sid);
			System.out.println(s.getStateName());
			Country c = s.getCountry();
			System.out.println(c.getCountryName());
			hs.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean addStateToExistingCountry() {
		boolean isInserted = false;
		Session hs = null;
		Transaction tx = null;
		try {
			hs = HibernateUtils.getSession();
			tx = hs.beginTransaction();

			Country c = hs.get(Country.class, 1);

			State s1 = new State();
			s1.setStateName("Pune");
			s1.setCountry(c);

			hs.save(s1);

			tx.commit();
			hs.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return isInserted;
	}

	public boolean deleteOneStateFromCountry() {
		boolean isInserted = false;
		Session hs = null;
		Transaction tx = null;
		try {
			hs = HibernateUtils.getSession();
			tx = hs.beginTransaction();

			State s = new State();
			s.setStateId(4);

			hs.delete(s);
			tx.commit();
			hs.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isInserted;
	}

	public boolean deleteAllStates() {
		boolean isInserted = false;
		Session hs = null;
		Transaction tx = null;
		try {
			hs = HibernateUtils.getSession();
			tx = hs.beginTransaction();

			String hql = "From State where country.countryId=:cid";
			Query query = hs.createQuery(hql);
			query.setParameter("cid", 1);
			List<State> sList = query.getResultList();
			if (!sList.isEmpty()) {
				for (State s : sList) {
					hs.delete(s);
				}
			}
			tx.commit();
			hs.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isInserted;
	}
}
