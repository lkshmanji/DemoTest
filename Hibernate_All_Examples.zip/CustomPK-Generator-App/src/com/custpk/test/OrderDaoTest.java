package com.custpk.test;

import com.custpk.dao.OrderDao;
import com.custpk.entities.Order;

public class OrderDaoTest {

	public static void main(String[] args) {

		Order o = new Order();
		o.setOrderBy("Dean");
		o.setOrderPrice(8989.90);

		OrderDao dao = new OrderDao();
		boolean isInserted = dao.insert(o);

		System.out.println("Record inserted : " + isInserted);

	}

}
