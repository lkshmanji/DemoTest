package com.custpk.dao;

import java.io.Serializable;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.custpk.entities.Order;

public class OrderDao {
	public boolean insert(Order entity) {
		boolean isInserted = false;
		Configuration cfg = new Configuration().configure();
		cfg.configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session hs = sf.openSession();
		Transaction tx = hs.beginTransaction();

		Serializable id = hs.save(entity);
		if (id != null) {
			isInserted = true;
		}
		tx.commit();
		hs.close();
		sf.close();
		return isInserted;
	}
}
