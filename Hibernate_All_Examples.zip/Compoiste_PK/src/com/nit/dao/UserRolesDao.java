package com.nit.dao;

import java.io.Serializable;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.nit.entities.UsersRoles;

public class UserRolesDao {

	public boolean insert(UsersRoles entity) {
		boolean isInserted = false;
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session hs = sf.openSession();
		Transaction tx = hs.beginTransaction();
		Serializable id = hs.save(entity);
		if (id != null) {
			isInserted = true;
		}
		tx.commit();
		hs.close();
		sf.close();
		return isInserted;
	}

	public UsersRoles findByIds(int uid, int rid) {

		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session hs = sf.openSession();

		UsersRoles ur = new UsersRoles();
		ur.setRoleId(rid);
		ur.setUserId(uid);
		
		ur = (UsersRoles) hs.get(UsersRoles.class, ur);

		hs.close();
		sf.close();
		return ur;

	}

}
