package com.nit.test;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Demo {
	
	public static void main(String[] args)throws Exception {
		String str = "12/Jan/2017";
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MMM/yyyy");
		Date d = sdf.parse(str);
		System.out.println(d);
	}

}
