package com.nit.test;

import com.nit.dao.UserRolesDao;
import com.nit.entities.UsersRoles;

public class UserRolesDaoTest {

	public static void main(String[] args) {

		UserRolesDao dao = new UserRolesDao();

		/*
		 * UsersRoles ur = new UsersRoles(); ur.setRoleId(201);
		 * ur.setUserId(101);
		 * 
		 * boolean isInserted = dao.insert(ur); System.out.println("Status : " +
		 * isInserted);
		 */

		UsersRoles ur = dao.findByIds(101, 201);
		System.out.println(ur);
	}

}
