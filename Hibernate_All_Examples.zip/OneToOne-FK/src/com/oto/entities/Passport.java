package com.oto.entities;

import java.util.Date;

public class Passport {

	private Integer passportId;
	private String passportNum;
	private Date issuedDt;
	private Date expiryDt;

	private Person person;

	public Integer getPassportId() {
		return passportId;
	}

	public void setPassportId(Integer passportId) {
		this.passportId = passportId;
	}

	public String getPassportNum() {
		return passportNum;
	}

	public void setPassportNum(String passportNum) {
		this.passportNum = passportNum;
	}

	public Date getIssuedDt() {
		return issuedDt;
	}

	public void setIssuedDt(Date issuedDt) {
		this.issuedDt = issuedDt;
	}

	public Date getExpiryDt() {
		return expiryDt;
	}

	public void setExpiryDt(Date expiryDt) {
		this.expiryDt = expiryDt;
	}

	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}

	@Override
	public String toString() {
		return "Passport [passportId=" + passportId + ", passportNum="
				+ passportNum + ", issuedDt=" + issuedDt + ", expiryDt="
				+ expiryDt + ", person=" + person + "]";
	}

}
