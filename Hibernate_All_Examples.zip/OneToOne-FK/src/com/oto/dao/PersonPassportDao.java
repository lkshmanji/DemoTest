package com.oto.dao;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.oto.entities.Passport;
import com.oto.entities.Person;
import com.oto.util.HibernateUtil;

public class PersonPassportDao {

	public void savePersonWithPassport() throws Exception {
		Session hs = HibernateUtil.getSession();
		Transaction tx = hs.beginTransaction();

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MMM/yyyy");

		Passport passport = new Passport();
		passport.setPassportNum("JHLJL79979");
		passport.setIssuedDt(new Date());
		passport.setExpiryDt(sdf.parse("01/Jan/2028"));

		Person p = new Person();
		p.setDob(sdf.parse("01/Jun/1995"));
		p.setEmail("smith@in.com");
		p.setPersonName("Smith");

		passport.setPerson(p);

		hs.save(passport);

		tx.commit();
		hs.close();
	}

}
