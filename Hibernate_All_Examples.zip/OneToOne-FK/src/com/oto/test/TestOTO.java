package com.oto.test;

import com.oto.dao.PersonPassportDao;

public class TestOTO {
	public static void main(String[] args) throws Exception {
		PersonPassportDao dao = new PersonPassportDao();
		dao.savePersonWithPassport();
	}
}
