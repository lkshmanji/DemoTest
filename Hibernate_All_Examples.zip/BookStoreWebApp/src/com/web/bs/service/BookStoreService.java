package com.web.bs.service;

import java.util.ArrayList;
import java.util.List;

import com.web.bs.dao.BookStoreDao;
import com.web.bs.entities.BookEntity;
import com.web.bs.model.BookModel;

/**
 * This class is written to handle all business operations for Book_store
 * functionality
 * 
 * @author Ashok
 *
 */
public class BookStoreService {

	BookStoreDao dao = new BookStoreDao();

	/**
	 * This method is used to store book data by calling dao method
	 * 
	 * @param model
	 * @return boolean
	 */
	public boolean save(BookModel model) {
		BookEntity entity = new BookEntity();

		// Converting model to Entity
		entity.setBookId(model.getBookId());
		entity.setBookName(model.getBookName());
		entity.setAuthorName(model.getAuthorName());
		entity.setIsbn(model.getIsbn());
		entity.setBookPrice(model.getPrice());
		entity.setIsActive("Y");

		// Calling dao method and returning status
		return dao.insertBook(entity);
	}

	/**
	 * This method will retrive all books from dao and will return data in model
	 * format
	 * 
	 * @return
	 */
	public List<BookModel> retrieveAllBooks(int pageNo, int pageSize) {

		List<BookModel> models = new ArrayList<BookModel>();

		// retrieving data from dao method
		List<BookEntity> entitiesList = dao.findAll(pageNo, pageSize);

		// Convert each entity to model
		for (BookEntity entity : entitiesList) {

			BookModel model = new BookModel();
			model.setBookId(entity.getBookId());
			model.setBookName(entity.getBookName());
			model.setAuthorName(entity.getAuthorName());
			model.setIsbn(entity.getIsbn());
			model.setIsActive(entity.getIsActive());
			model.setPrice(entity.getBookPrice());
			model.setCreateDt(entity.getCreateDt());
			// Adding each model to collection
			models.add(model);
		}
		return models;
	}

	public long retriveRecordsCnt() {
		return dao.findTotalRecordsCnt();
	}
	
	public boolean deleteBookById(int bid) {
		return dao.deleteBook(bid);
	}

}
