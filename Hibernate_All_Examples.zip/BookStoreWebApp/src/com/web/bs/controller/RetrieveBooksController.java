package com.web.bs.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.web.bs.model.BookModel;
import com.web.bs.service.BookStoreService;

@WebServlet("/RetrieveBooksController")
public class RetrieveBooksController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		BookStoreService service = new BookStoreService();

		int pageNo = 1;

		String pn = request.getParameter("pn");
		if (pn != null && !"".equals(pn)) {
			pageNo = Integer.parseInt(pn);
		}
		request.setAttribute("currPageNo", pageNo);

		long totRecords = service.retriveRecordsCnt();
		int pageSize = 3;
		long totalPagesReq = (totRecords / pageSize)
				+ (totRecords % pageSize > 0 ? 1 : 0);
		request.setAttribute("pagesReq", totalPagesReq);

		List<BookModel> modelsList = service.retrieveAllBooks(pageNo, pageSize);

		// Storing book models in request scope
		request.setAttribute("books", modelsList);

		// Dispatch the request to jsp to print the data
		RequestDispatcher rd = request.getRequestDispatcher("viewBooks.jsp");
		rd.forward(request, response);

	}

}
