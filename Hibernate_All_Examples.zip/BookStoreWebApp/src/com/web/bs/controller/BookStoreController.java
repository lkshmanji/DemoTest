package com.web.bs.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.web.bs.model.BookModel;
import com.web.bs.service.BookStoreService;

/**
 * Servlet implementation class BookStoreController
 */
@WebServlet("/BookStoreController")
public class BookStoreController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		// capture form data and storing in model object
		BookModel model = new BookModel();
		model.setBookName(request.getParameter("bookName"));
		model.setAuthorName(request.getParameter("authorName"));
		model.setIsbn(request.getParameter("bookIsbn"));
		model.setPrice(Double.parseDouble(request.getParameter("bookPrice")));

		// calling service method
		BookStoreService service = new BookStoreService();
		boolean isInserted = service.save(model);

		if (isInserted) {
			// display success msg
			request.setAttribute("succMsg", "Record inserted successfully");
		} else {
			// display failure msg
			request.setAttribute("errMsg", "Failed to insert");
		}

		// Redirect to same page
		request.getRequestDispatcher("index.jsp").forward(request, response);
	}

}
