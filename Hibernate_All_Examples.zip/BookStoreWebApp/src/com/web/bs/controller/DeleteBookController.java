package com.web.bs.controller;

import java.awt.print.Book;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.web.bs.service.BookStoreService;

/**
 * Servlet implementation class DeleteBookController
 */
@WebServlet("/DeleteBookController")
public class DeleteBookController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		String bookId = request.getParameter("bookId");
		if (bookId != null && !"".equals(bookId)) {
			int bid = Integer.parseInt(bookId);
			BookStoreService service = new BookStoreService();
			boolean isDeleted = service.deleteBookById(bid);
			
			request.getRequestDispatcher("RetrieveBooksController").forward(
					request, response);

		}

	}
}
