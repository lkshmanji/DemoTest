package com.web.bs.dao;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.web.bs.entities.BookEntity;
import com.web.bs.util.HibernateUtil;

/**
 * This class is written to handle database operations for Book_store table
 * 
 * @author Ashok
 *
 */
public class BookStoreDao {

	/**
	 * This method is used to store book data
	 * 
	 * @param entity
	 * @return
	 */
	public boolean insertBook(BookEntity entity) {
		boolean isInserted = false;
		Session hs = null;
		Transaction tx = null;
		try {
			hs = HibernateUtil.getSession();
			tx = hs.beginTransaction();
			Serializable id = hs.save(entity);
			if (id != null) {
				isInserted = true;
			}
			tx.commit();
			hs.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (hs != null)
				hs.close();
		}

		return isInserted;
	}

	/**
	 * This method is used to retrieve all books details
	 * 
	 * @return
	 */
	public List<BookEntity> findAll(int pageNo, int pageSize) {
		List<BookEntity> booksList = null;
		Session hs = null;
		try {
			hs = HibernateUtil.getSession();
			String hqlQuery = "From BookEntity where isActive='Y'";
			Query query = hs.createQuery(hqlQuery);

			// Pagination methods
			query.setFirstResult((pageNo - 1) * pageSize);
			query.setMaxResults(pageSize);

			booksList = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (hs != null)
				hs.close();
		}
		return booksList;
	}

	/**
	 * This method is used to get total records count from table
	 * 
	 * @return
	 */
	public long findTotalRecordsCnt() {
		long cnt = 0;
		Session hs = null;
		try {
			hs = HibernateUtil.getSession();
			String hqlQuery = "select count(1) from BookEntity where isActive='Y'";
			Query query = hs.createQuery(hqlQuery);
			List<Long> list = query.getResultList();
			if (!list.isEmpty()) {
				cnt = list.get(0);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (hs != null)
				hs.close();
		}
		return cnt;
	}

	/**
	 * This method is used to make book record as in-active
	 * 
	 * @param bid
	 * @return
	 */
	public boolean deleteBook(int bid) {
		boolean isDeleted = false;
		Session hs = null;
		Transaction tx = null;
		try {
			hs = HibernateUtil.getSession();
			tx = hs.beginTransaction();
			String hql = "update BookEntity set isActive='N' where bookId=:bid";
			Query query = hs.createQuery(hql);
			query.setParameter("bid", bid);
			int no = query.executeUpdate();
			if (no > 0) {
				isDeleted = true;
			}
			tx.commit();
			hs.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (hs != null)
				hs.close();
		}
		return isDeleted;
	}

}
