package com.nit.test;

import java.util.Date;

import com.nit.dao.CarDao;
import com.nit.entities.Car;

public class CarDaoTest {

	public static void main(String[] args) {

		Car c = new Car();
		c.setCarColor("White");
		c.setCarName("Safari");
		c.setMfgDt(new Date());

		CarDao dao = new CarDao();
		boolean flag = dao.insert(c);
		System.out.println("Status : " + flag);
	}

}
