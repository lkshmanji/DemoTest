package com.ihm.tps.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "CURRENT_ACCOUNT")
public class CurrentAccount extends Account {

	@Column(name = "TX_LIMIT")
	private Double txLimit;

	public Double getTxLimit() {
		return txLimit;
	}

	public void setTxLimit(Double txLimit) {
		this.txLimit = txLimit;
	}

}
