package com.nit.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.hib.entities.Robot;

public class RobotDao {
	public void insert(Robot entity) {
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("JPA-App1");
		EntityManager manager = factory.createEntityManager();
		manager.getTransaction().begin();
		manager.persist(entity);
		manager.getTransaction().commit();
		manager.close();
		factory.close();
	}

	public void findById(Integer robotId) {
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("JPA-App1");

		EntityManager manager = factory.createEntityManager();

		Robot r = manager.find(Robot.class, robotId);

		System.out.println(r);
		manager.close();
		factory.close();

	}

	public void findAll() {
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("JPA-App1");
		EntityManager manager = factory.createEntityManager();
		String jpql = "From Robot";
		Query query = manager.createQuery(jpql);
		List<Robot> list = query.getResultList();
		for (Robot r : list) {
			System.out.println(r);
		}
		manager.close();
		factory.close();
	}

}
