package com.nit.dao;

import java.io.Serializable;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.hib.entities.Robot;
import com.hib.util.HibernateUtil;

public class RobotDao {
	public boolean insert(Robot entity) {
		boolean isInserted = false;
		Session hs = null;
		Transaction tx = null;
		try {
			hs = HibernateUtil.buildSession();
			tx = hs.beginTransaction();
			Serializable id = hs.save(entity);
			if (id != null)
				isInserted = true;
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isInserted;
	}
}
