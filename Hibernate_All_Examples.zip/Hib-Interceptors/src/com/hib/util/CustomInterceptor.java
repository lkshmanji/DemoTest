package com.hib.util;

import java.io.Serializable;

import org.hibernate.EmptyInterceptor;
import org.hibernate.type.Type;

public class CustomInterceptor extends EmptyInterceptor {

	@Override
	public boolean onSave(Object entity, Serializable id, Object[] state,
			String[] propertyNames, Type[] types) {
		System.out.println("Record saved");
		return super.onSave(entity, id, state, propertyNames, types);
	}
	
	@Override
	public void onDelete(Object entity, Serializable id, Object[] state,
			String[] propertyNames, Type[] types) {
		System.out.println("Record deleted...");
		super.onDelete(entity, id, state, propertyNames, types);
	}

}
