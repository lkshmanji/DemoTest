package com.nit.dao;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Filter;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.hib.entities.Robot;
import com.hib.util.HibernateUtil;

public class RobotDao {
	public boolean insert(Robot entity) {
		boolean isInserted = false;
		Session hs = null;
		Transaction tx = null;
		try {
			hs = HibernateUtil.buildSession();
			tx = hs.beginTransaction();
			Serializable id = hs.save(entity);
			if (id != null)
				isInserted = true;
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isInserted;
	}

	public void findAll() {
		Session hs = null;
		try {
			hs = HibernateUtil.buildSession();
			Query query = hs.createQuery("From Robot");
		
			Filter filter = hs.enableFilter("dataFilter");
			filter.setParameter("robotType", "Funny");
			
			List<Robot> list = query.getResultList();
			System.out.println(list.size());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
