package com.otm.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.otm.entiteis.Author;
import com.otm.entiteis.Book;
import com.otm.util.HibernateUtil;

public class AuthorBooksDao {

	public boolean saveAuthorWithBooks() {
		boolean isInserted = false;
		Session hs = null;
		Transaction tx = null;
		try {
			hs = HibernateUtil.getSession();
			tx = hs.beginTransaction();

			// Insert Author object
			Author a = new Author();
			a.setAuthorName("Gaven King");
			a.setEmail("gvs@sun.com");

			Book b1 = new Book();
			b1.setBookName("JSE");
			b1.setIsbn("ISBN001");
			b1.setPrice(100.00);

			Book b2 = new Book();
			b2.setBookName("JEE");
			b2.setIsbn("ISBN002");
			b2.setPrice(200.00);

			Book b3 = new Book();
			b3.setBookName("EJB");
			b3.setIsbn("ISBN003");
			b3.setPrice(250.00);

			Map<String, Book> booksMap = new HashMap<String, Book>();
			booksMap.put("Child-1", b1);
			booksMap.put("Child-2", b2);
			booksMap.put("Child-3", b3);

			a.setBooks(booksMap);

			Serializable id = hs.save(a);
			if (id != null) {
				isInserted = true;
			}
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			if (hs != null)
				hs.close();
		}
		return isInserted;
	}

}
