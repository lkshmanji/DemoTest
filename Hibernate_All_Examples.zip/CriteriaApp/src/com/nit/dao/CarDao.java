package com.nit.dao;

import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.nit.entities.Car;

public class CarDao {
	public List<Car> findAll(String orderType) {
		List<Car> carsList = null;
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session hs = sf.openSession();
		Criteria c = hs.createCriteria(Car.class);
		c.add(Restrictions.eq("carColor", "Black"));

		if (orderType.equals("asc")) {
			c.addOrder(Order.asc("carPrice"));
		} else {
			c.addOrder(Order.desc("carPrice"));
		}
		carsList = c.list();
		hs.close();
		return carsList;
	}

	public List<Car> findByPriceAndColor(String clr, double price) {
		List<Car> carsList = null;
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session hs = sf.openSession();
		Criteria c = hs.createCriteria(Car.class);

		c.add(Restrictions.eq("carColor", clr));
		c.add(Restrictions.le("carPrice", price));

		carsList = c.list();
		hs.close();
		return carsList;
	}

	public List<Car> findByColors(String clr1, String clr2) {
		List<Car> carsList = null;
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session hs = sf.openSession();
		Criteria c = hs.createCriteria(Car.class);

		Criterion c1 = Restrictions.eq("carColor", "White");
		Criterion c2 = Restrictions.eq("carColor", "Black");

		c.add(Restrictions.or(c1, c2));

		carsList = c.list();
		hs.close();
		return carsList;
	}

	public List<Car> findByIds(List<Integer> ids) {
		List<Car> carsList = null;
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session hs = sf.openSession();

		Criteria c = hs.createCriteria(Car.class);

		c.add(Restrictions.in("carId", ids));

		carsList = c.list();
		hs.close();
		return carsList;
	}

	public List<Car> findByMfgDates(Date sDt, Date eDt) {
		List<Car> carsList = null;
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session hs = sf.openSession();
		Criteria c = hs.createCriteria(Car.class);
		c.add(Restrictions.between("mfgDt", sDt, eDt));
		carsList = c.list();
		hs.close();
		return carsList;
	}

	public List<Object[]> findNameColorPrice() {
		List<Object[]> carsList = null;
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session hs = sf.openSession();
		Criteria c = hs.createCriteria(Car.class);
		ProjectionList pList = Projections.projectionList();
		pList.add(Projections.property("carName"));
		pList.add(Projections.property("carColor"));
		pList.add(Projections.property("carPrice"));
		c.setProjection(pList);
		carsList = c.list();
		hs.close();
		return carsList;
	}

	public Double findMaxPrice() {
		List<Double> carsList = null;
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session hs = sf.openSession();
		Criteria c = hs.createCriteria(Car.class);
		c.setProjection(Projections.max("carPrice"));
		carsList = c.list();
		hs.close();
		if (!carsList.isEmpty()) {
			return carsList.get(0);
		}
		return null;
	}

	public List<Object[]> retriveAll() {

		List<Object[]> carsList = null;
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session hs = sf.openSession();

		SQLQuery query = hs.createSQLQuery("SELECT * FROM CAR_DETAILS");
		carsList = query.list();
		return carsList;
	}
}
