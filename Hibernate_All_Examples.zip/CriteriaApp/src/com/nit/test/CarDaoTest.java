package com.nit.test;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.nit.dao.CarDao;
import com.nit.entities.Car;

public class CarDaoTest {

	public static void main(String[] args) throws Exception {
		CarDao dao = new CarDao();

		// List<Car> list = dao.findAll("asc");

		// List<Car> list = dao.findByPriceAndColor("Black", 1000000.00);

		// List<Car> list = dao.findByColors("Black", "White");
		List<Integer> ids = new ArrayList();
		ids.add(1);
		ids.add(3);
		ids.add(5);

		// List<Car> list = dao.findByIds(ids);

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MMM/yyyy");
		Date sDt = sdf.parse("01/Jan/2016");
		Date eDt = sdf.parse("31/Dec/2016");

		/*
		 * List<Car> list = dao.findByMfgDates(sDt, eDt);
		 * 
		 * if (!list.isEmpty()) { for (Car c : list) { System.out.println(c); }
		 * }
		 */

		/*List<Object[]> objArrList = dao.findNameColorPrice();

		for (Object[] objArr : objArrList) {
			System.out.print(objArr[0] + "\t");
			System.out.print(objArr[1] + "\t");
			System.out.println(objArr[2]);

		}*/
		
		/*double price = dao.findMaxPrice();
		System.out.println("Max price : "+price);*/

		
		List<Object[]> objArrList = dao.retriveAll();

		for (Object[] objArr : objArrList) {
			System.out.print(objArr[0] + "\t");
			System.out.print(objArr[1] + "\t");
			System.out.print(objArr[2] + "\t");
			System.out.print(objArr[3] + "\t");
			System.out.println(objArr[4]);

		}
	}
}
