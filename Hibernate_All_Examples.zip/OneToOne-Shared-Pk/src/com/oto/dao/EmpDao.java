package com.oto.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.oto.entities.EmpDetails;
import com.oto.entities.Employee;
import com.oto.util.HibernateUtil;

public class EmpDao {

	public void insertEmpData() {
		Session hs = HibernateUtil.getSession();
		Transaction tx = hs.beginTransaction();

		Employee emp = new Employee();
		emp.setEmpName("Raj");
		emp.setEmail("raj@in.com");

		EmpDetails edet = new EmpDetails();
		edet.setFname("Raj");
		edet.setLname("kumar");
		edet.setMname("B");

		// associate parent to child and child to parent
		emp.setEmpDetails(edet);
		edet.setEmp(emp);

		hs.save(emp);

		tx.commit();
		hs.close();

	}

	public void findByEid(int eid) {
		Session hs = HibernateUtil.getSession();
		Employee e = hs.get(Employee.class, eid);
		hs.close();
	}

}
