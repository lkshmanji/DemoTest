package com.oto.test;

import com.oto.dao.EmpDao;
import com.oto.util.HibernateUtil;

public class TestOTO {
	public static void main(String[] args) throws Exception {
		EmpDao dao = new EmpDao();
		//dao.insertEmpData();
		dao.findByEid(1);
		HibernateUtil.closeSf();
	}
}
