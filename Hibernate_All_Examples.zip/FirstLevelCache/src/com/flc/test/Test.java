package com.flc.test;

import com.flc.dao.BookStoreDao;
import com.flc.util.HibernateUtil;

public class Test {

	public static void main(String[] args) {
		BookStoreDao dao = new BookStoreDao();
		 dao.findById(21);
		//dao.findByHql(21);
		 
		 HibernateUtil.closeSf();
	}

}
