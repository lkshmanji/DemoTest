package com.nit.entities;

import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name = "USER_PROFILES")
public class UserProfiles {

	@Id
	@GeneratedValue
	@Column(name = "USER_ID")
	private Integer uid;

	@Column(name = "USER_NAME")
	private String uname;

	@Lob
	@Column(name = "USER_IMAGE")
	private byte[] userImage;

	public Integer getUid() {
		return uid;
	}

	public void setUid(Integer uid) {
		this.uid = uid;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public byte[] getUserImage() {
		return userImage;
	}

	public void setUserImage(byte[] userImage) {
		this.userImage = userImage;
	}

}
