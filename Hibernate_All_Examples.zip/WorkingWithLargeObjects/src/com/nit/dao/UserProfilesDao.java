package com.nit.dao;

import java.io.Serializable;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.nit.entities.UserProfiles;

public class UserProfilesDao {

	public boolean insertUser(UserProfiles entity) {
		boolean isInserted = false;
		try {
			Configuration cfg = new Configuration();
			cfg.configure();
			SessionFactory sf = cfg.buildSessionFactory();
			Session hs = sf.openSession();
			Transaction tx = hs.beginTransaction();

			Serializable id = hs.save(entity);
			if (id != null) {
				isInserted = true;
			}
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isInserted;
	}

	public UserProfiles findById(Integer uid) {
		UserProfiles up = null;
		try {
			Configuration cfg = new Configuration();
			cfg.configure();
			SessionFactory sf = cfg.buildSessionFactory();
			Session hs = sf.openSession();
			up = hs.get(UserProfiles.class, uid);
			hs.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return up;
	}

}
