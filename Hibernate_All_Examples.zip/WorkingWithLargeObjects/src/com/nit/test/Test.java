package com.nit.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;

import com.nit.dao.UserProfilesDao;
import com.nit.entities.UserProfiles;

public class Test {

	public static void main(String[] args) throws Exception {
		File f = new File(
				"C:\\Users\\akumarbollepalli\\Documents\\My-Data\\My Images\\1.jpg");
		FileInputStream fis = new FileInputStream(f);
		byte[] bArr = new byte[(int) f.length()];
		fis.read(bArr);
		fis.close();

		UserProfiles up = new UserProfiles();
		up.setUname("Ashok");
		up.setUserImage(bArr);

		UserProfilesDao dao = new UserProfilesDao();
		/*
		 * boolean flag = dao.insertUser(up); System.out.println("Inserted : " +
		 * flag);
		 */

		UserProfiles obj = dao.findById(1);

		FileOutputStream fos = new FileOutputStream("profile.jpg");
		fos.write(obj.getUserImage());
		fos.flush();
		fos.close();

	}
}
