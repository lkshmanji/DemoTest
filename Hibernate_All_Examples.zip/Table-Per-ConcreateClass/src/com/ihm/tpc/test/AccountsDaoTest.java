package com.ihm.tpc.test;

import java.util.Date;

import com.ihm.tpc.dao.AccountsDao;
import com.ihm.tpc.entities.CurrentAccount;
import com.ihm.tpc.entities.SavingsAccount;

public class AccountsDaoTest {

	public static void main(String[] args) {

		AccountsDao dao = new AccountsDao();

		SavingsAccount sa = new SavingsAccount();
		sa.setMinBal(1000.00);
		sa.setBranchName("S.R.Nagar");
		sa.setHolderName("Raju");
		sa.setOpenDt(new Date());

		CurrentAccount ca = new CurrentAccount();
		ca.setBranchName("Ameerpet");
		ca.setHolderName("Mahesh");
		ca.setTxLimit(40000.00);
		ca.setOpenDt(new Date());

		dao.saveCurrentAccount(ca);
		// dao.saveSavingsAccount(sa);

	}

}
