package com.nit.dao;

import java.io.Serializable;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.nit.entities.Product;

public class ProductDao {

	public boolean insert(Product entity) {
		boolean isInserted = false;

		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session hs = sf.openSession();
		Transaction tx = hs.beginTransaction();
		System.out.println("B4 : "+entity);
		Serializable ser = hs.save(entity);
		if (ser != null) {
			isInserted = true;
		}
		System.out.println("AFter :" +entity);
		tx.commit();
		hs.close();
		sf.close();
		return isInserted;
	}

}
