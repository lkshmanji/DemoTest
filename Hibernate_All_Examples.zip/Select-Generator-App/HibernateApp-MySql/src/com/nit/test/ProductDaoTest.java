package com.nit.test;

import com.nit.dao.ProductDao;
import com.nit.entities.Product;

public class ProductDaoTest {
	public static void main(String[] args) {

		Product entity = new Product();
		entity.setName("Keyboard");
		entity.setPrice(14500.00);

		ProductDao dao = new ProductDao();
		boolean isInserted = dao.insert(entity);
		if (isInserted) {
			System.out.println("Record inserted");
		} else {
			System.out.println("Failed to insert..");
		}
	}

}
