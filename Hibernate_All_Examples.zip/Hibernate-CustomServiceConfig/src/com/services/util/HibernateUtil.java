package com.services.util;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;
import org.hibernate.service.jdbc.connections.spi.ConnectionProvider;

import com.services.service.CustomConnProviderService;

public class HibernateUtil {

	private static SessionFactory sf = null;

	private HibernateUtil() {
	}

	public static Session buildSession() {
		if (sf == null) {
			Configuration cfg = new Configuration();
			cfg.configure();
			ServiceRegistry registry =
					new ServiceRegistryBuilder()
					.applySettings(cfg.getProperties())
					.addService(ConnectionProvider.class, new CustomConnProviderService())
					.buildServiceRegistry();
			sf = cfg.buildSessionFactory(registry);
		}
		return sf.openSession();
	}

}
