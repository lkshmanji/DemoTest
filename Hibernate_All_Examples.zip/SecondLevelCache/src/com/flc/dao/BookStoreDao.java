package com.flc.dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.cache.ehcache.EhCacheRegionFactory;

import com.flc.entities.BookEntity;
import com.flc.util.HibernateUtil;

public class BookStoreDao {

	public void findById(Integer bookId) {
		Session hs = HibernateUtil.getSession();
		BookEntity b1 = hs.get(BookEntity.class, bookId);
		System.out.println(b1);
		hs.close();
	}

	public void findAllByHQL() {
		Session hs = HibernateUtil.getSession();
		String hql = "From BookEntity";
		org.hibernate.query.Query query = hs.createQuery(hql);
		query.setCacheable(true);
		List<BookEntity> list = query.getResultList();
		System.out.println(list.size());
		hs.close();
	}
}
