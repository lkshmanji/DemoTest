package com.nit.mtm.test;

import java.util.HashSet;
import java.util.Set;

import javax.management.relation.Role;

import com.nit.mtm.dao.UsersDao;
import com.nit.mtm.entities.Roles;
import com.nit.mtm.entities.Users;

public class Test {

	public static void main(String[] args) throws Exception {
		UsersDao dao = new UsersDao();

		Users users = new Users();
		users.setUsername("Ryan");

		Roles r1 = new Roles();
		r1.setRoleName("Admin");

		Roles r2 = new Roles();
		r2.setRoleName("Manager");

		Set<Roles> rolesSet = new HashSet<Roles>();
		rolesSet.add(r1);
		rolesSet.add(r2);

		users.setRoles(rolesSet);

	//	dao.insert(users);
		
		dao.findById(1);

	}
}
