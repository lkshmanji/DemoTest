package com.nit.mtm.entities;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "ROLES_MASTER")
public class Roles {
	@Id
	@GeneratedValue
	@Column(name = "ROLE_ID")
	private Integer roleId;

	@Column(name = "ROLED_NAME")
	private String roleName;

	@ManyToMany(mappedBy = "roles", 
			cascade = CascadeType.ALL)
	private Set<Users> users;

	public Integer getRoleId() {
		return roleId;
	}

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public Set<Users> getUsers() {
		return users;
	}

	public void setUsers(Set<Users> users) {
		this.users = users;
	}

}
