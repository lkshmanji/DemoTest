package com.nit.mtm.dao;

import java.io.Serializable;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.nit.mtm.entities.Users;
import com.nit.mtm.util.HibernateUtils;

public class UsersDao {

	public void insert(Users u) {
		Session hs = HibernateUtils.getSession();
		Transaction tx = hs.beginTransaction();
		Serializable id = hs.save(u);
		System.out.println("inserted : " + id);
		tx.commit();
		hs.close();
	}

	public void findById(Integer uid) {
		Session hs = HibernateUtils.getSession();
		Users u = hs.get(Users.class, uid);
		System.out.println(u);
		hs.close();
	}

}
