package com.nit.test;

import com.nit.dao.BookDAO;

public class BookDAOTest {

	public static void main(String[] args) {
		BookDAO dao = new BookDAO();
		// String name = dao.findNameById(1);
		// System.out.println("Book Name : " + name);
		dao.findBooksByPrice(50);
	}
}
