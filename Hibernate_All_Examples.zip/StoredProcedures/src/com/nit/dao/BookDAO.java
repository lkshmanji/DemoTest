package com.nit.dao;

import java.util.List;

import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.hibernate.Session;

import com.hib.util.HibernateUtil;

public class BookDAO {

	public String findNameById(int id) {
		Session hs = HibernateUtil.buildSession();
		String procName = "GET_BOOK_NAME_BY_ID";
		StoredProcedureQuery spQuery = hs.createStoredProcedureQuery(procName);
		spQuery.registerStoredProcedureParameter(0, Integer.class,
				ParameterMode.IN);
		spQuery.registerStoredProcedureParameter(1, String.class,
				ParameterMode.OUT);
		spQuery.setParameter(0, id);
		spQuery.execute();
		String bookName = (String) spQuery.getOutputParameterValue(1);

		hs.close();
		return bookName;
	}

	public void findBooksByPrice(int price) {
		Session hs = HibernateUtil.buildSession();

		String procName = "GET_BOOKS_BY_PRICE";
		StoredProcedureQuery sp = hs.createStoredProcedureQuery(procName);
		sp.registerStoredProcedureParameter(1, Integer.class, ParameterMode.IN);
		sp.registerStoredProcedureParameter(2, Class.class,
				ParameterMode.REF_CURSOR);
		sp.setParameter(1, price);
		sp.execute();
		List<Object[]> listObjArr = sp.getResultList();
		for (Object[] objArr : listObjArr) {
			for (Object obj : objArr) {
				System.out.println(obj);
			}
			System.out.println("");
		}

		hs.close();
	}
}
