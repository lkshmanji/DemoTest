package com.nit.dao;

import java.io.Serializable;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.nit.entities.Person;
import com.nit.util.HibernateUtils;

public class PersonDao {

	public boolean insert(Person p) {
		boolean isInserted = false;
		Session hs = HibernateUtils.getSession();
		Transaction tx = hs.beginTransaction();
		Serializable id = hs.save(p);
		if (id != null) {
			isInserted = true;
		}
		tx.commit();
		hs.close();
		return isInserted;
	}

}
