package com.nit.entities;

import java.util.Date;

import javax.persistence.Embeddable;

@Embeddable
public class Passport {

	private String passportNum;
	private Date issuedDt;
	private Date expiryDt;

	public String getPassportNum() {
		return passportNum;
	}

	public void setPassportNum(String passportNum) {
		this.passportNum = passportNum;
	}

	public Date getIssuedDt() {
		return issuedDt;
	}

	public void setIssuedDt(Date issuedDt) {
		this.issuedDt = issuedDt;
	}

	public Date getExpiryDt() {
		return expiryDt;
	}

	public void setExpiryDt(Date expiryDt) {
		this.expiryDt = expiryDt;
	}

	@Override
	public String toString() {
		return "Passport [passportNum=" + passportNum + ", issuedDt="
				+ issuedDt + ", expiryDt=" + expiryDt + "]";
	}

}
