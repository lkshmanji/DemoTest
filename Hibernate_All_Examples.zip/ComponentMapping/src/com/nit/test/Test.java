package com.nit.test;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.hibernate.Hibernate;

import com.nit.dao.PersonDao;
import com.nit.entities.Passport;
import com.nit.entities.Person;
import com.nit.util.HibernateUtils;

public class Test {

	public static void main(String[] args) throws Exception {

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

		// component class
		Passport passport = new Passport();
		passport.setPassportNum("AB979khkg");
		passport.setIssuedDt(new Date());
		passport.setExpiryDt(sdf.parse("06/01/2028"));

		Person p = new Person();
		p.setPersonName("Robert");
		p.setEmail("rob@in.com");
		p.setDob(sdf.parse("20/05/1991"));

		// setting component to main
		p.setPassport(passport);

		PersonDao dao = new PersonDao();
		boolean flag = dao.insert(p);
		System.out.println("Status : " + flag);

		HibernateUtils.closeSf();

	}

}
