package com.nit.otm.dao;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.nit.otm.entities.Author;
import com.nit.otm.util.HibernateUtils;

public class AuthorDao {

	public void insert(Author a) {
		Session hs = HibernateUtils.getSession();
		Transaction tx = hs.beginTransaction();
		hs.save(a);
		tx.commit();
		hs.close();
	}

	public void findByid(int id) throws FileNotFoundException, IOException {
		Session hs = HibernateUtils.getSession();
		Author a = (Author) hs.get(Author.class, id);
		System.out.println(a);
		hs.close();
	}

	public void deleteAuthor(int aid) throws FileNotFoundException, IOException {
		Session hs = HibernateUtils.getSession();
		Transaction tx = hs.beginTransaction();
		String hql = "From Author where authorId=:id";
		Query query = hs.createQuery(hql);
		query.setParameter("id", aid);
		List<Author> list = query.getResultList();
		if (!list.isEmpty()) {
			Author a = list.get(0);
			hs.delete(a);
		}
		tx.commit();
		hs.close();
	}

	public void joinQuery(int id) {
		Session hs = HibernateUtils.getSession();

		String hql = "SELECT A.authorName,b.bookName FROM Author A, Book b "
				+ " where A.authorId=b.author.authorId "
				+ " and A.authorId=:id";
		
		Query query = hs.createQuery(hql);
		query.setParameter("id",id);
		List<Object[]> objArrList = query.getResultList();

		for(Object[] objArr : objArrList){
			System.out.print(objArr[0]+"--"+objArr[1]);;
		}
		
		hs.close();
	}
}
