package com.nit.otm.entities;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "AUTHOR_DETAILS")
public class Author {
	@Id
	@GeneratedValue
	@Column(name = "AUTHOR_ID")
	private Integer authorId;

	@Column(name = "AUTHOR_NAME")
	private String authorName;

	@Column(name = "AUTHOR_EMAIL")
	private String email;

	@OneToMany(mappedBy = "author",cascade = CascadeType.ALL)
	private Set<Book> books;

	public Integer getAuthorId() {
		return authorId;
	}

	public void setAuthorId(Integer authorId) {
		this.authorId = authorId;
	}

	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Set<Book> getBooks() {
		return books;
	}

	public void setBooks(Set<Book> books) {
		this.books = books;
	}

	@Override
	public String toString() {
		return "Author [authorId=" + authorId + ", authorName=" + authorName
				+ ", email=" + email + ", books=" + books + "]";
	}

}
