package com.nit.otm.test;

import java.util.HashSet;
import java.util.Set;

import com.nit.otm.dao.AuthorDao;
import com.nit.otm.entities.Author;
import com.nit.otm.entities.Book;

public class Test {

	public static void main(String[] args) throws Exception {

		AuthorDao dao = new AuthorDao();

		Author a = new Author();
		a.setAuthorName("Cathie Sierra");
		a.setEmail("cs@sun.com");

		Book b1 = new Book();
		b1.setBookName("JSE");
		b1.setBookPrice(400.00);
		b1.setIsbn("ISBN1");
		b1.setAuthor(a);

		Book b2 = new Book();
		b2.setBookName("JEE");
		b2.setBookPrice(400.00);
		b2.setIsbn("ISBN2");
		b2.setAuthor(a);

		Set<Book> booksSet = new HashSet<>();
		booksSet.add(b1);
		booksSet.add(b2);

		a.setBooks(booksSet);

		//dao.insert(a);

		// dao.findByid(1);
		// dao.deleteAuthor(1);
		dao.joinQuery(4);
	}
}
