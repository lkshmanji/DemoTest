package com.nit.mto.entities;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Entity;

@Entity
@Table(name = "SCHOOL_DETAILS")
public class School {

	@Id
	@GeneratedValue
	@Column(name = "school_id")
	private Integer schoolId;
	@Column(name = "school_name")
	private String schoolName;
	@Column(name = "school_princi_name")
	private String princiName;

	public Integer getSchoolId() {
		return schoolId;
	}

	public void setSchoolId(Integer schoolId) {
		this.schoolId = schoolId;
	}

	public String getSchoolName() {
		return schoolName;
	}

	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	public String getPrinciName() {
		return princiName;
	}

	public void setPrinciName(String princiName) {
		this.princiName = princiName;
	}

}
