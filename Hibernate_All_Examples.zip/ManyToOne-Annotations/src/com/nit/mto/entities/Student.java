package com.nit.mto.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.CascadeType;
import javax.persistence.Table;
import javax.persistence.ManyToOne;

@Entity
@Table(name = "STUDENT_DETAILS")
public class Student {

	@Id
	@GeneratedValue
	@Column(name = "student_id")
	private Integer sid;
	@Column(name = "student_name")
	private String sname;
	@Column(name = "student_rank")
	private Long rank;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "school_id")
	private School school;

	public Integer getSid() {
		return sid;
	}

	public void setSid(Integer sid) {
		this.sid = sid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public Long getRank() {
		return rank;
	}

	public void setRank(Long rank) {
		this.rank = rank;
	}

	public School getSchool() {
		return school;
	}

	public void setSchool(School school) {
		this.school = school;
	}

	@Override
	public String toString() {
		return "Student [sid=" + sid + ", sname=" + sname + ", rank=" + rank
				+ ", school=" + school + "]";
	}

}
