package com.nit.mto.test;

import com.nit.mto.dao.StudentDao;
import com.nit.mto.entities.School;
import com.nit.mto.entities.Student;

public class Test {

	public static void main(String[] args) throws Exception {
	
		School school = new School();
		school.setSchoolName("Sri chaitanya");
		school.setPrinciName("Ram");
		
		Student s1 = new Student();
		s1.setRank(10l);
		s1.setSname("Bharat");
		s1.setSchool(school);
		
		Student s2 = new Student();
		s2.setRank(20l);
		s2.setSname("Ganesh");
		s2.setSchool(school);
		
		StudentDao dao = new StudentDao();
		//dao.insert(s1);
		//dao.insert(s2);
		
		//dao.findBySid(1);
		dao.deleteBySid(1);
	
	}
}
