package com.nit.mto.dao;

import java.io.Serializable;

import javax.sql.rowset.serial.SerialArray;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.nit.mto.entities.Student;
import com.nit.mto.util.HibernateUtils;

public class StudentDao {

	public void insert(Student s) {
		Session hs = HibernateUtils.getSession();
		Transaction tx = hs.beginTransaction();
		Serializable id = hs.save(s);
		System.out.println("Record inserted : " + id);
		tx.commit();
		hs.close();
	}

	public void findBySid(int sid) {
		Session hs = HibernateUtils.getSession();
		Transaction tx = hs.beginTransaction();
		Student s = (Student) hs.get(Student.class, sid);
		System.out.println(s);
		tx.commit();
		hs.close();
	}

	public void deleteBySid(int sid) {
		Session hs = HibernateUtils.getSession();
		Transaction tx = hs.beginTransaction();
		Student s = new Student();
		s.setSid(sid);
		hs.delete(s);
		tx.commit();
		hs.close();
	}

}
