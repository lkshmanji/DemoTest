
public  class Example {
       int  b;
	public  Example() {
		//super();compiler automatically places the zero parameter constructor
		System.out.println("Example zero-parameter");
	}
   public  Example(int a) {
    	// super();compiler automatically places the zero parameter constructor
	System.out.println("Example one-parameter");
     }
}
  
/*
 * super() is java keyword ,used to access super class Constructors from subclass Constructors only
 * super. is used to call super class variables and methods from subclass members
 * 
 */
