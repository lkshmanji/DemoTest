//Example is a super class
public class Example1 {

	void m1() {
		System.out.println("super class of m1 method");
	}
	void m2() {
		System.out.println("super class of m2 method");
	}
}
