
public class P {
 void m1() {
	 
 }
}
