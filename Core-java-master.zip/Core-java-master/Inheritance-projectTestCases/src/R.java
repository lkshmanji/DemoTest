
public class R implements I5{
 public void m1() {
	 
 }
}
