
public class Example {//super class 
	static int a=10;
	int b=20;

}
