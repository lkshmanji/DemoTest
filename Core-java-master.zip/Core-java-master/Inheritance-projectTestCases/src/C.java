
public class C extends A{
	//extends  <---------Is used for developing inheritance  between two classes or two interfaces.....
}
