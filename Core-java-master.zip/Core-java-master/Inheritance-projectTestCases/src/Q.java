
public class Q extends P {

}
