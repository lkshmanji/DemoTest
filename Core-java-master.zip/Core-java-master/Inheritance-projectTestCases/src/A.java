//Inheritance is the process of creating new class or new object is derived from existing class or existing object .
//by obtaining type ,behavior and properties.
public class A {
//extends  <---------Is used for developing inheritance  between two classes or two interfaces.....
}
