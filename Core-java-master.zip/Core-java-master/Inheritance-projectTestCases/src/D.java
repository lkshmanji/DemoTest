
public class D implements I3 {
//implements  <------ Is used for developing inheritance between interface ,class..........
}
