
public class E implements   I4{
	//implements  <------ Is used for developing inheritance between interface ,class..........
}
