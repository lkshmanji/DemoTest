
public interface I5 {
	 void m1();

}
