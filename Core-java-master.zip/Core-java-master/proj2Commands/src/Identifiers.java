
public class Identifiers {

	public static void main(String[] args) {
		System.out.println("identifiers are:\nalphabets\nnumbers 0-09\nspecial characters _,$");
         System.out.println("identifier shoud not start with number");
         System.out.println("Special characters only allowed _,$");
         System.out.println( "identifiers shoud not contain space in the middle of word,if we want provide+"
         		+ "use connector_ unserscore");
         System.out.println("identifires are case sensitive");
         System.out.println("keywords are can't use user defined identifier");
	}

}
