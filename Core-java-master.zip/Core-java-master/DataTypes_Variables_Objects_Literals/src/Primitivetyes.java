
public class Primitivetyes {

	public static void main(String[] args) {
		
		byte b=127;
		short s=220;
		int i=4;
		long l=8;
		char c='a';
		boolean b1=true;
		System.out.println(b); 
		System.out.println(s); 
		System.out.println(i); 
		System.out.println(l); 
		System.out.println(c); 
		System.out.println(b1); 
		
		
	}

}
