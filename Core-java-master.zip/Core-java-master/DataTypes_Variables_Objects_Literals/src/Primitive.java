/*
 -->Data types are used to store data Temporally in Computer 
 
 -->Size of memory Location and Range of Data
 
 -->Primitive DataTypes used to Store SINGLE value at a time.
 
 
 */

public class Primitive {
	
	public static void mian(String[] args) {//main method 
	
	//Primitive Data Types(8)
	
		//Numeric(6)
	
			//-->Integer(4)
	
				byte b=126;
				
				short s=226;
				
				int i=400;
				
				long l=800;
				
			//-->Floating Point(2)
				
				char c='a';
				
				boolean bo=true;
				
	
		
		
		
		System.out.println("Byte value:: "+b);
		
		System.out.println("Short value:: "+s);
		
		System.out.println("Int value:: "+i);
		
		System.out.println("Long value:: "+l);
		
		System.out.println("Char value:: "+c);
		
		System.out.println("Boolean value:: "+bo);
		
	}//main method 
	
}//class

