
public class Lit_Test {

	public static void main(String[] args) {
		//Literal is a Constant. 
		//ex: 10,20.4,'a',"abc",tru

	}

}
