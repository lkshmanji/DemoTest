
public class MethodsAndArguments {
	static void m4(int a, int b) {//() variables declared in brackets are called parameters
		 int c=a+b;
		 System.out.print("result= "+c);
	 }
	 public static void main(String[] args) {
		 m4(10,20);//arguments order and type,type means type of values.
	 }
	 
}
