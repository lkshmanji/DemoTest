//sub class 
public abstract class Abtract_Cases {
	
abstract void m1();

}
