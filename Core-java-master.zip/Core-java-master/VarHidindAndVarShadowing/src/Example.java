/*
 * Creating a variable in subclass with super class variable name both are same  is called variable HIDING.
 */
public class Example {
       int x=10;//super class
       int y=20;
       void m1(){
    	   System.out.println("m1");
       }
	
		
	}


